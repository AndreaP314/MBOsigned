function [ output_args ] = load_Migration_Data( )

load ALL_CENSUS_DATA_FEB_2015
whos

% A:   latitude and longitude
% BS: the boundary  plot(BS(:,1), BS(:,2) ,'.r');  % but it's a crappy one
     % better off using the plot_USA_Boundary.m file in the boundary folder
% CODES = ZIP CODES
% INFO: same as before; size 3075 x 9
% POP = population
% MIG = migration matrix; not symmetric!!!

spy(MIG)
% close all; figure(1); colormap('hot'); imagesc(log(MIG)); colorbar; set(gca,'FontSize',18)


end

