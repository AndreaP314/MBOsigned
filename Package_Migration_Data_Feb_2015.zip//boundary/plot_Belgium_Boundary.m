function [ output_args ] = plot_Belgium_Boundary( input_args )

% Belgium state boundary map

close all
clc
% set(0,'DefaultFigureWindowStyle','docked')
format long
load BE_mihai.txt 
W = BE_mihai;
size(W)
% subplot(1,2,2)
plot(W(:,2),W(:,3),'.b');
%% axis([2.5 6.5 49 52]);
hold on
W(:,4) = W(:,4)+1
% input('snsext');
%W(4947:5043,:)
% input('look...');
N = length(W)

plot_bel(1,4974,W)
plot_bel(4975,6755,W)
plot_bel(6756,7180,W)
plot_bel(7181,8529,W)
plot_bel(8530,8648,W)
plot_bel(8649,N,W)


end


function  plot_bel(st,ed,W)
a=st;
for i=st+1:ed
    if   W(i,1) == W(i-1,1)  
      b=i;
    else
           hold on
           plot(W((a:b),2),W((a:b),3),'-r');   
        %%   axis([2.5 6.5 49 52]);
           [ (a:b)' W((a:b),2) W((a:b),3) ]
            [a b];
          %input('Done...');
        a=b+1;
        b = a;
    end
end
 
[a b];
 [ (a:b)' W((a:b),2) W((a:b),3) ];
 hold on
           plot(W((a:b),2),W((a:b),3),'-r');   
          %% axis([2.5 6.5 49 52]);
           
%  input('Done...');
end



%{

% W = USA_mihai;
% W= sortrows(W,-1)
% S= unique(W(:,1))'



marked = zeros(length(W),1);
subplot(1,2,2)

W(1:100,:)
a=1
input('snext');
for i=2:length(W)
    if W(i,4) == W(i-1,4)+1;
        b = i;
    else
        a
        b
        hold on
        plot(W((a:b),2),W((a:b),3),'-r');   
        %% axis([2.5 6.5 49 52]);
        % input('newwwww');
        a=b+1
    end
end


% for s=1
%     s
%    q = find(W(:,1));
%    id = W(:,4);
%    r=1; R=[]; R(r) = q(1);
%    for k=2:length(id)
%        if id(k) == id(k-1)+1
%            r=r+1;
%            R(r) = q(k);
%        else
%            % R(r+1) = R(1);
%            hold on
%            marked(R)=1;
%            plot(W(R,2),W(R,3),'-r');   
%            axis([2.5 6.5 49 52]);
%            %input('next set');
%            r=1; R=[];
%            R(r)=q(k);
%        end
%    end
%    % 
%    % 
%    % input('nexttt');
% end

% w = find(marked==0);
% disp('hmhm');
% W(w,:)    
%}