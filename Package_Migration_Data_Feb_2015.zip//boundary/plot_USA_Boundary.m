function [ output_args ] = plot_USA_Boundary(LW )

% LW = linewidth (larger means thicker lines)

 if nargin==0
     LW = 2;
 end

% set(0,'DefaultFigureWindowStyle','docked')
format short

% load BE_mihai.txt 
% W = BE_mihai;

load USA_mihai.txt
W = USA_mihai;
% whos

% Kill alaska and haway
kilx = find(W(:,2) < -140);
kily = find(W(:,3) > 50);
W([kilx' kily'],:) = [];

size(W);
% subplot(1,2,2)
% plot(W(:,2),W(:,3),'.b');
%% axis([2.5 6.5 49 52]);
hold on

W(:,4) = W(:,4)+1;
 % input('snsext');
%W(4947:5043,:)
% input('look...');
N = length(W);
N;
% plot_bel(1,N,W)

plot_bel(1,7,W,LW)
plot_bel(7+1,35,W,LW)
plot_bel(35+1,142,W,LW)
plot_bel(142+1,3089,W,LW)
plot_bel(3089+1,3102,W,LW)
plot_bel(3102+1,4698,W,LW)
plot_bel(4698+1,4733,W,LW)
plot_bel(4733+1,4757,W,LW)
plot_bel(4757+1,4759,W,LW)
plot_bel(4759+1,6436,W,LW)
plot_bel(6436+1,6461,W,LW)
plot_bel(6461+1,10077,W,LW)
plot_bel(10077+1,10714,W,LW)
plot_bel(10714+1,N,W,LW)


end


function  plot_bel(st,ed,W,LW)
a=st;
for i=st+1:ed
    if   W(i,1) == W(i-1,1)  
      b=i;
    else
           hold on
           plot(W((a:b),2),W((a:b),3),'k','LineWidth',LW);   
           % axis([-130 -60 20 50 ]);
           [ (a:b)' W((a:b),2) W((a:b),3) ];
            [a b];
             %input('Done...');
        a=b+1;
        b = a;
    end
end
 
[a b];
[ (a:b)' W((a:b),2) W((a:b),3) ];
hold on
plot(W((a:b),2),W((a:b),3),'k','LineWidth',LW);   
axis([-130 -60 20 50 ]);
LW;       
%  input('Done...');
end



%{

marked = zeros(length(W),1);
subplot(1,2,2)

W(1:100,:)
a=1
input('snext');
for i=2:length(W)
    if W(i,4) == W(i-1,4)+1;
        b = i;
    else
        a
        b
        hold on
        plot(W((a:b),2),W((a:b),3),'-r');   
        %% axis([2.5 6.5 49 52]);
        input('newwwww');
        a=b+1
    end
end


%}