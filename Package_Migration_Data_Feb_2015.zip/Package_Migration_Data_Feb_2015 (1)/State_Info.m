function [ output_args ] = State_Info( input_args )
close all

addpath(genpath('boundary'));
addpath(genpath('lib'));  addpath(genpath('lib2'));


load INFO2k_raw
whos

% Variabels in INFO2k_raw:

% COUNTIES_IN_STATE: is a structure of length 52 (number of states)
        % where COUNTIES_IN_STATE(i).ind_cty  is a vector with the labels
        % (indices) of all counties in that state.
        % Alaska (State 1): has the first 67 counties, with labels  {1,2,....67}
        % AK (State 2): the next 27 counties , with labels  {68,69, ..., 94}
        % etc..
        
% HASH2_Code_Label: a vector of size 72153 that maps the Zip-Codes to States
        % where 
        % HASH2_Code_Label(i) = 0 if ZipCode i does not exist
        % HASH2_Code_Label(i) = j if ZipCode i corresponds to county j
% HASH2_Label_Code: a vector of size  3219 (total number of counties)
        % HASH2_Label_Code(i) = j if j is the ZIP-CODE of county i

% INFO: an array of size 3219 x 9, each row is a county, and columns are:
    % ZIP_CODES = INFO(:,1);
    % POPULATION = INFO(:,2);
    % Columns 8 and 9 are latitude and logitude.
    % I don't recall exactly what the other columns are, but you probably
    % don't need them, I don't think I ever used them.
    
% STATE_NAMES: just a vector (size 52) with strings - the state names 

check_States_DoNot_Overlap(COUNTIES_IN_STATE);
size (INFO)

B = [ -INFO(:,8)  INFO(:,9)];
% plot(B(:,1), B(:,2),'.','Color', [ 0 1 0]); return
R = [cos(pi/2)  -sin(pi/2)
     sin(pi/2)   cos(pi/2) ];
B = B * R;

POP = INFO(:,2);  % population
TOT_POP = sum(INFO(:,2));   % total population

size(HASH2_Code_Label); size(HASH2_Label_Code);
A = B;
plot(B(:,1), B(:,2),'.','Color', [ 0 1 0]); % entire US map (not just mainland)
% hold on

nrr = numel(COUNTIES_IN_STATE);
disp([ 'Nr of states  =' int2str(nrr ) ]);

mainland = setdiff((1:nrr),[ 2, 12, 52]);
% mainland = [ 2, 12, 52]   % 1:nrr;

nrTotalCounties = 0;
figure(1);
for i = 1:nrr
    
    disp( [  int2str(i) '. == ' STATE_NAMES{i} '==' ] );
    i;
    STATE_NAMES{i};
    ind_cty = COUNTIES_IN_STATE(i).ind_cty;  % list ofcounties in this state
    sizeState = length(ind_cty);
    disp( [ '      Size of state = ' int2str(sizeState) ] );
    
    % disp(COUNTIES_IN_STATE(i).ind_cty);
    
    COUNTIES_IN_STATE(i).code_cty = HASH2_Label_Code(ind_cty);
    COUNTIES_IN_STATE(i).state = STATE_NAMES{i};
    COUNTIES_IN_STATE(i).size = sizeState;
    
    Z = A(ind_cty,:);
    COUNTIES_IN_STATE(i).Z = Z;

    plot(Z(:,1), Z(:,2),'.','Color', rand(1,3));
    hold on
    nrTotalCounties = nrTotalCounties + sizeState;
%   input('press key for next state...');
end

disp(['nrTotalCounties = '  int2str(nrTotalCounties) ]);

%% You may want to focus on mainland only
figure(2);
nrMainlandCounties = 0;
for i = mainland 
    Z = COUNTIES_IN_STATE(i).Z;
    plot(Z(:,1), Z(:,2),'.','Color', rand(1,3));
    hold on
    nrMainlandCounties = nrMainlandCounties + COUNTIES_IN_STATE(i).size;
end
disp(['nrMainlandCounties = '  int2str(nrMainlandCounties) ]);

%% Plot the boundary (mainland only)
hold on
LW = 3;
plot_USA_Boundary(LW );


save data_COUNTIES_IN_STATE    COUNTIES_IN_STATE  

disp('saved to file');
end



function check_States_DoNot_Overlap(COUNTIES_IN_STATE)

nrS = numel(COUNTIES_IN_STATE);

nrOverlap = 0;
for i = 1:(nrS-1)
    for j = (i+1):nrS
        com = intersect( COUNTIES_IN_STATE(i).ind_cty  ,  COUNTIES_IN_STATE(j).ind_cty );
        nrCommon = length(com);
        if nrCommon > 0
           disp( [  int2str(i) ' '  int2str(j) 'this should not happen!!!' ] );
           nrOverlap = nrOverlap + 1;
           input('');
        end
    end
end

disp([ 'Nr pairs of states that overlap = '  int2str(nrOverlap) ]); 
end



